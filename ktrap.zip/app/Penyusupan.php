<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Penyusupan extends Model
{
    //
    protected $table = 'auth';
    protected $fillable = [
    	'notifikasi'
    ];

    public function detail_penyusupan(){
    	return $this->hasMany('DetailPenyusupan','session','session');
    }
}
