<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailPenyusupan extends Model
{
    //
    protected $table = 'input';

    public function inputan(){
    	return $this->belongsTo('Penyusupan','session','session');
    }
}
