<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
// use App\Console\Commands\Telegram;
use Telegram\Bot\Laravel\Facades\Telegram;
use App\JumlahSerangan;
use App\Penyusupan;
use App\Notifikasi;


class CekSerangan extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'do:notif';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Pengecekan Notifikasi Otomatis';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // $jumlah = Penyusupan::where('notifikasi',0)->count();

        $notif = Penyusupan::where('notifikasi',0)
                ->first();
        // dd($jumlah);

        // @for ($i = 1; $i <= $jumlah; $i++)
            $text = "<b>Serangan baru Telah Masuk!!!</b>\n"
            . "Dengan keterangan sebagai berikut\n"
            . "Username : "
            . $notif->username
            . " || Password : "
            . $notif->password
            . "\n\n"
            . "Serangan Masuk Pada\n"
            . $notif->timestamp;
 
        Telegram::sendMessage([
            'chat_id' => env('TELEGRAM_CHANNEL_ID', '-1001168404793.0'),
            'parse_mode' => 'HTML',
            'text' => $text
        ]);

        Penyusupan::where('notifikasi',0)
            ->first()
            ->update(['notifikasi' => 1],['notif_time' => NOW()]);
    }
}
