<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notifikasi extends Model
{
    //
    protected $table = 'notifikasi';

    protected $fillable = [
    	'id','id_session','success','timestamp'
    ];
}
