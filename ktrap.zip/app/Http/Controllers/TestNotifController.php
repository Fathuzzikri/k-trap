<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Telegram\Bot\FileUpload\InputFile;
use Telegram\Bot\Laravel\Facades\Telegram;
use App\Notifikasi;

class TestNotifController extends Controller
{
    //

	public function TestLog()
    {
        $notif = Notifikasi::all();
        return view('notif',compact('notif'));
    }

    public function TestNotifikasi()
    {
        // $request->validate([
        //     'email' => 'required|email',
        //     'message' => 'required'
        // ]);
        $timestamp = NOW();
        $text = "TEST NOTIFIKASI BERHASIL\n"
        		."Notifikasi Masuk Pada\n"
        		. $timestamp;
 
        Telegram::TestLog([
            'chat_id' => env('TELEGRAM_CHANNEL_ID', '-1001168404793.0'),
            'parse_mode' => 'HTML',
            'text' => $text
        ]);
 
        return redirect()->action('NotifikasiController@TampilkanLog');
    }
}
