<?php

namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Telegram\Bot\FileUpload\InputFile;
use Telegram\Bot\Laravel\Facades\Telegram;
use App\Notifikasi;
use App\Penyusupan;

class NotifikasiController extends Controller
{
    public function updatedActivity()
    {
        $activity = Telegram::getUpdates();
        dd($activity);
    }
 
    public function showMessage()
    {
        $notif = Penyusupan::where('notifikasi',1)->get();
        return view('notif',compact('notif'));
    }
 
    public function sendMessage()
    {
        // $request->validate([
        //     'email' => 'required|email',
        //     'message' => 'required'
        // ]);
        $text = "<b>NOTIFIKASI TEST BERHASIL</b>\n"
            . "Notifikasi Diterima Pada\n"
            . NOW();
 
        Telegram::sendMessage([
            'chat_id' => env('TELEGRAM_CHANNEL_ID', '-1001168404793.0'),
            'parse_mode' => 'HTML',
            'text' => $text
        ]);
        
        Notifikasi::insert([
            ['id_session' =>"TESTING",'success'=>'1','timestamp' => NOW()]
        ]);


        return redirect()->action('NotifikasiController@showMessage');
    }
}