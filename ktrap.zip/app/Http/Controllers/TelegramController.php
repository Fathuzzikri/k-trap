<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Telegram\Bot\FileUpload\InputFile;
use Telegram\Bot\Laravel\Facades\Telegram;
use App\Notifikasi;

class TelegramController extends Controller
{
    //
    public function KirimPesan()
    {
        $notif = Notifikasi::all();

        return view('notif', compact('notif'));
}
