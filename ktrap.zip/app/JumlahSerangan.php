<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JumlahSerangan extends Model
{
    //
    protected $table = 'jumlah_serangan';

    protected $fillable = [
    	'id','jumlah_serangan'
    ];
}
